#!/bin/sh
$XGETTEXT $(find . -name "*.cpp") -o $podir/okular_comicbook.pot
