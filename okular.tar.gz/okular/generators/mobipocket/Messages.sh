#!/bin/sh
$XGETTEXT *.cpp -o $podir/okular_mobi.pot
