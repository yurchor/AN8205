#!/bin/sh
$XGETTEXT $(find . -name "*.cpp") -o $podir/okular_epub.pot
