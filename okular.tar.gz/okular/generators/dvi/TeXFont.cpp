// -*- Mode: C++; c-basic-offset: 2; indent-tabs-mode: nil; c-brace-offset: 0; -*-
#include <config.h>

#include "TeXFont.h"

TeXFont::~TeXFont()
{
}
